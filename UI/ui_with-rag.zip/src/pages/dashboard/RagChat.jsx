import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, FileText, Loader2, RefreshCw, BookOpen, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import api from '../../services/api';
import toast from 'react-hot-toast';
import './RagChat.css';

const fadeUp = { hidden: { opacity: 0, y: 10 }, visible: { opacity: 1, y: 0 } };

export default function RagChat() {
  const [messages, setMessages] = useState([
    {
      id: 'welcome',
      role: 'assistant',
      content: 'Hello! I am your Speak ClaimAI assistant. Ask me anything about your uploaded documents, policies, or knowledge graph.',
      timestamp: new Date(),
      metadata: null
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date(),
      metadata: null
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await api.post('/knowledge-graph/chat', { query: userMessage.content });

      const { answer, sources = [], confidence = 0, retrieved_chunks = 0 } = response.data.response;

      const assistantMessage = {
        id: Date.now().toString(),
        role: 'assistant',
        content: answer || 'I could not generate a response. Please try again.',
        timestamp: new Date(),
        metadata: {
          sources,
          confidence,
          retrieved_chunks
        }
      };

      // ✅ Fix: setLoading(false) BEFORE setMessages so React batches correctly
      setLoading(false);
      setMessages((prev) => [...prev, assistantMessage]);

    } catch (error) {
      toast.error('Failed to get response from backend');
      console.error(error);
      setLoading(false);
    }
  };

  const handleClearChat = () => {
    setMessages([{
      id: Date.now().toString(),
      role: 'assistant',
      content: 'Chat history cleared. How can I help you today?',
      timestamp: new Date(),
      metadata: null
    }]);
  };

  return (
    <motion.div
      className="rag-chat-container"
      initial="hidden"
      animate="visible"
      variants={{ visible: { transition: { staggerChildren: 0.1 } } }}
    >
      <div className="chat-header">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <FileText className="text-cyan-400" />
            Speak ClaimAI
          </h1>
          <p className="text-gray-400 mt-1 text-sm">
            Ask questions to search through your extracted knowledge base, policies, and claims.
          </p>
        </div>
        <button className="clear-chat-btn" onClick={handleClearChat} title="Clear Chat">
          <RefreshCw size={18} />
          <span>Clear Chat</span>
        </button>
      </div>

      <div className="chat-window">
        <div className="messages-area">
          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                variants={fadeUp}
                initial="hidden"
                animate="visible"
                exit={{ opacity: 0, y: -10 }}
                className={`message-wrapper ${msg.role}`}
              >
                <div className="message-avatar">
                  {msg.role === 'assistant' ? <Bot size={20} /> : <User size={20} />}
                </div>
                <div className="message-content">
                  <div className="message-text">{msg.content}</div>
                  {msg.metadata && msg.metadata.sources && msg.metadata.sources.length > 0 && (
                    <div className="message-sources">
                      <div className="sources-header">
                        <BookOpen size={14} />
                        <span>Sources ({msg.metadata.sources.length})</span>
                      </div>
                      <div className="sources-list">
                        {msg.metadata.sources.map((source, idx) => (
                          <div key={idx} className="source-item">
                            <CheckCircle2 size={12} />
                            <span>{source.filename}</span>
                            {source.section && <span className="section-info">{source.section}</span>}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="message-time">
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </motion.div>
            ))}

            {/* ✅ Fix: explicit key + exit animation so AnimatePresence unmounts cleanly */}
            {loading && (
              <motion.div
                key="typing-loader"
                variants={fadeUp}
                initial="hidden"
                animate="visible"
                exit={{ opacity: 0, y: -10 }}
                className="message-wrapper assistant"
              >
                <div className="message-avatar">
                  <Bot size={20} />
                </div>
                <div className="message-content">
                  <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              </motion.div>
            )}
            <div ref={messagesEndRef} />
          </AnimatePresence>
        </div>

        <form className="chat-input-area" onSubmit={handleSend}>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your claims, policies, or coverage..."
            disabled={loading}
            className="chat-input"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="send-button"
          >
            <Send size={20} />
          </button>
        </form>
      </div>
    </motion.div>
  );
}