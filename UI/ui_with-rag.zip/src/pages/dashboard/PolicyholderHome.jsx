import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { FileText, Clock, CheckCircle2, AlertCircle, PlusCircle, ArrowRight, RefreshCw, Shield } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useClaims } from '../../hooks/useClaims'
import { LoadingState, ErrorState, EmptyState } from '../../components/StateViews'
import { useAuthStore } from '../../store/authStore'
import api from '../../services/api'

const PRIORITY_COLOR = {
  low:      '#10B981',
  medium:   '#F59E0B',
  high:     '#EF4444',
  critical: '#8B5CF6',
}

const PIPELINE_STEPS = [
  'fnol_received',
  'coverage_verification',
  'damage_assessment',
  'fraud_scoring',
  'settlement_pending',
  'settled',
]

const STEP_LABEL = {
  fnol_received:         'FNOL Intake',
  coverage_verification: 'Coverage Verify',
  damage_assessment:     'Damage Assessment',
  fraud_scoring:         'Fraud Scoring',
  settlement_pending:    'Settlement',
  settled:               'Settled',
}

const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }
const stagger = { visible: { transition: { staggerChildren: 0.08 } } }

function PipelineTracker({ claim }) {
  const stepIdx = PIPELINE_STEPS.indexOf(claim.status)
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {PIPELINE_STEPS.map((step, i) => {
        const done   = i < stepIdx
        const active = i === stepIdx
        return (
          <div key={step} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
              background: done   ? 'rgba(16,185,129,0.2)'
                         : active ? 'rgba(79,70,229,0.2)'
                         : 'rgba(255,255,255,0.05)',
              border: `2px solid ${done ? '#10B981' : active ? '#818CF8' : 'rgba(255,255,255,0.1)'}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '0.75rem', fontWeight: 700,
              color: done ? '#10B981' : active ? '#818CF8' : 'var(--text-dim)',
            }}>
              {done ? '✓' : i + 1}
            </div>
            <span style={{
              fontSize: '0.88rem',
              fontWeight: active ? 600 : 400,
              color: done ? 'var(--text-muted)' : active ? 'var(--text)' : 'var(--text-dim)',
            }}>
              {STEP_LABEL[step]}
            </span>
            {active && <span className="badge badge-info" style={{ marginLeft: 'auto' }}>In Progress</span>}
            {done   && <span style={{ marginLeft: 'auto', fontSize: '0.75rem', color: 'var(--success)' }}>Done</span>}
          </div>
        )
      })}
    </div>
  )
}

export default function PolicyholderHome() {
  const navigate = useNavigate()
  const user     = useAuthStore(s => s.user)
  const { claims, stats, loading, error, refetch, STATUS_CONFIG } = useClaims()

  // Active policies count
  const [activePolicies, setActivePolicies] = useState(null)
  useEffect(() => {
    api.get('/policies/mine')
      .then(r => setActivePolicies(r.data.filter(p => !p.is_expired).length))
      .catch(() => setActivePolicies(0))
  }, [])

  // Pick the most recent in-progress claim for the pipeline tracker
  const inProgressClaim = claims.find(c => !['settled', 'closed', 'rejected'].includes(c.status))

  const statCards = [
    { icon: Shield,       label: 'Active Policies', value: activePolicies === null ? '—' : activePolicies, color: '#8B5CF6', bg: 'rgba(139,92,246,0.12)', onClick: () => navigate('/dashboard/policies') },
    { icon: FileText,     label: 'Total Claims',    value: loading ? '—' : stats.total,      color: '#06B6D4', bg: 'rgba(6,182,212,0.12)'   },
    { icon: CheckCircle2, label: 'Settled',          value: loading ? '—' : stats.settled,    color: '#10B981', bg: 'rgba(16,185,129,0.12)'  },
    { icon: Clock,        label: 'In Progress',      value: loading ? '—' : stats.inProgress, color: '#F59E0B', bg: 'rgba(245,158,11,0.12)'  },
    { icon: AlertCircle,  label: 'Needs Attention',  value: loading ? '—' : stats.needsAttn,  color: '#EF4444', bg: 'rgba(239,68,68,0.12)'   },
  ]

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger}>
      {/* Heading */}
      <motion.div variants={fadeUp} className="page-heading" style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <h1>My Claims</h1>
          <p>Welcome back, <strong>{user?.full_name}</strong> — track and manage your insurance claims in real time</p>
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
          <button className="btn-ghost"
            style={{ padding: '8px 14px', fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 6 }}
            onClick={() => navigate('/dashboard/policies')}>
            <Shield size={14}/> My Policies
          </button>
          <button className="btn-ghost"
            style={{ padding: '8px 14px', fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 6 }}
            onClick={refetch} title="Refresh">
            <RefreshCw size={14}/> Refresh
          </button>
          <button className="btn-primary"
            style={{ padding: '8px 14px', fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 6 }}
            onClick={() => navigate('/dashboard/claims/new')}>
            <PlusCircle size={14}/> File Claim
          </button>
        </div>
      </motion.div>

      {/* Stat cards */}
      <motion.div variants={fadeUp} className="stats-grid">
        {statCards.map(s => (
          <div key={s.label} className="stat-card"
            onClick={s.onClick}
            style={{ cursor: s.onClick ? 'pointer' : 'default' }}
          >
            <div className="stat-card-icon" style={{ background: s.bg }}>
              <s.icon size={20} color={s.color}/>
            </div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </motion.div>

      {/* File new claim */}
      {/* <motion.div variants={fadeUp} style={{ marginBottom: 24 }}>
        <button
          className="btn-primary"
          style={{ gap: 8 }}
          onClick={() => navigate('/dashboard/claims/new')}
        >
          <PlusCircle size={16}/> File a New Claim
        </button>
      </motion.div> */}

      {/* Claims table */}
      <motion.div variants={fadeUp}>
        <div className="dash-section-title">
          <FileText size={16} color="var(--primary-light)"/> My Claims
        </div>

        {loading && <LoadingState label="Fetching your claims…"/>}
        {!loading && error && <ErrorState message={error} onRetry={refetch}/>}
        {!loading && !error && claims.length === 0 && (
          <EmptyState label="You haven't filed any claims yet. Click 'File a New Claim' to get started."/>
        )}

        {!loading && !error && claims.length > 0 && (
          <div className="dash-table-wrap">
            <table className="dash-table">
              <thead>
                <tr>
                  <th>Claim #</th>
                  <th>Type</th>
                  <th>Date Filed</th>
                  <th>Priority</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {claims.map(c => {
                  const st = STATUS_CONFIG[c.status] || { label: c.status, cls: 'badge-info' }
                  const dateStr = c.incident_date
                    ? new Date(c.incident_date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
                    : '—'
                  return (
                    <tr key={c.id}>
                      <td><code style={{ color: 'var(--primary-light)', fontSize: '0.82rem' }}>{c.claim_number}</code></td>
                      <td style={{ textTransform: 'capitalize' }}>{c.claim_type.replace(/_/g, ' ')}</td>
                      <td style={{ color: 'var(--text-muted)' }}>{dateStr}</td>
                      <td>
                        <span style={{
                          color: PRIORITY_COLOR[c.priority] || 'var(--text-muted)',
                          fontWeight: 600, fontSize: '0.8rem',
                        }}>
                          ● {c.priority?.charAt(0).toUpperCase() + c.priority?.slice(1)}
                        </span>
                      </td>
                      <td><span className={`badge ${st.cls}`}>{st.label}</span></td>
                      <td>
                        <button
                          className="btn-ghost"
                          style={{ padding: '6px 12px', fontSize: '0.8rem' }}
                          onClick={() => navigate(`/dashboard/claims/${c.id}`)}
                        >
                          View <ArrowRight size={12}/>
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      {/* Live pipeline tracker — most recent in-progress claim */}
      {inProgressClaim && (
        <motion.div variants={fadeUp} style={{ marginTop: 24 }}>
          <div className="dash-section-title">
            <Clock size={16} color="var(--primary-light)"/> Live Pipeline — {inProgressClaim.claim_number}
          </div>
          <div className="stat-card">
            <PipelineTracker claim={inProgressClaim}/>
          </div>
        </motion.div>
      )}
    </motion.div>
  )
}
