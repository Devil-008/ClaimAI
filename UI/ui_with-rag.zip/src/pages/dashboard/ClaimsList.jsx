import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { useClaims } from '../../hooks/useClaims'
import { LoadingState, ErrorState, EmptyState } from '../../components/StateViews'

const PRIORITY_COLOR = { low: '#10B981', medium: '#F59E0B', high: '#EF4444', critical: '#8B5CF6' }
const fadeUp = { hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }
const stagger = { visible: { transition: { staggerChildren: 0.07 } } }

export default function ClaimsList() {
  const navigate = useNavigate()
  const { claims, loading, error, refetch, STATUS_CONFIG } = useClaims()

  return (
    <motion.div initial="hidden" animate="visible" variants={stagger}>
      <motion.div variants={fadeUp} className="page-heading">
        <h1>All My Claims</h1>
        <p>Full history of all submitted insurance claims</p>
      </motion.div>

      {loading && <LoadingState label="Fetching claims…"/>}
      {!loading && error && <ErrorState message={error} onRetry={refetch}/>}
      {!loading && !error && claims.length === 0 && (
        <EmptyState label="No claims found. File your first claim to get started."/>
      )}

      {!loading && !error && claims.length > 0 && (
        <motion.div variants={fadeUp} className="dash-table-wrap">
          <table className="dash-table">
            <thead>
              <tr>
                <th>Claim #</th><th>Type</th><th>Incident Date</th>
                <th>Channel</th><th>Priority</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {claims.map(c => {
                const st = STATUS_CONFIG[c.status] || { label: c.status, cls: 'badge-info' }
                return (
                  <tr key={c.id}>
                    <td><code style={{ color: 'var(--primary-light)', fontSize: '0.82rem' }}>{c.claim_number}</code></td>
                    <td style={{ textTransform: 'capitalize' }}>{c.claim_type.replace(/_/g, ' ')}</td>
                    <td style={{ color: 'var(--text-muted)' }}>
                      {c.incident_date ? new Date(c.incident_date).toLocaleDateString('en-IN') : '—'}
                    </td>
                    <td style={{ color: 'var(--text-muted)', textTransform: 'capitalize' }}>{c.channel}</td>
                    <td>
                      <span style={{ color: PRIORITY_COLOR[c.priority], fontWeight: 600, fontSize: '0.8rem' }}>
                        ● {c.priority?.charAt(0).toUpperCase() + c.priority?.slice(1)}
                      </span>
                    </td>
                    <td><span className={`badge ${st.cls}`}>{st.label}</span></td>
                    <td>
                      <button
                        className="btn-ghost"
                        style={{ padding: '6px 12px', fontSize: '0.8rem' }}
                        onClick={() => navigate(`/dashboard/claims/${c.id}`)}
                      >
                        View →
                      </button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </motion.div>
      )}
    </motion.div>
  )
}
