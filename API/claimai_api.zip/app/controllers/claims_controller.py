import os, string, random
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from typing import List, Optional
from pydantic import BaseModel
from datetime import date, datetime, timedelta

from app.database.connection import get_db
from app.models.models import Claim, Policy, User, FNOLSubmission
from app.controllers.auth_controller import get_current_user
from app.services.email_escalation_service import notify_claimant_update

router = APIRouter(prefix="/claims", tags=["Claims"])


# ── Schemas ───────────────────────────────────────────────────
class ClaimOut(BaseModel):
    id: int
    policy_id: int
    claim_number: str
    claim_type: str
    status: str
    priority: str | None = None
    channel: str | None = None
    incident_date: date
    incident_description: str | None = None
    auto_settle_eligible: bool | None = False
    created_at: datetime | None = None
    document_url: str | None = None

    class Config:
        from_attributes = True


class ClaimCreate(BaseModel):
    policy_id: int
    incident_date: date
    incident_description: str
    claim_type: str
    channel: str = "web"


class ClaimDecisionPayload(BaseModel):
    action: str  # "approve" | "reject" | "partial_approve"
    notes: Optional[str] = None
    amount: Optional[float] = None


class ClaimDecisionOut(BaseModel):
    claim_id: int
    claim_number: str
    action: str
    new_status: str
    payment_ref: Optional[str] = None
    message: str


# ── Helper ────────────────────────────────────────────────────
def _next_bday(dt: datetime, n: int) -> datetime:
    d, c = dt, 0
    while c < n:
        d += timedelta(days=1)
        if d.weekday() < 5:
            c += 1
    return d


# ── Routes ────────────────────────────────────────────────────
@router.get("/", response_model=List[ClaimOut])
def list_claims(
    status: Optional[str] = Query(None),
    limit: int = Query(50, le=200),
    offset: int = Query(0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = db.query(Claim)
    # Policyholders only see their own claims
    if current_user.role == "policyholder":
        q = q.filter(Claim.claimant_id == current_user.id)
    # Adjuster sees only escalated_adjuster
    elif current_user.role == "adjuster":
        q = q.filter(Claim.status == "escalated_adjuster")
    # SIU sees only escalated_siu
    elif current_user.role == "siu_investigator":
        q = q.filter(Claim.status == "escalated_siu")
    if status:
        q = q.filter(Claim.status == status)
    return q.offset(offset).limit(limit).all()


@router.get("/{claim_id}", response_model=ClaimOut)
def get_claim(
    claim_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    claim = db.query(Claim).filter(Claim.id == claim_id).first()
    if not claim:
        raise HTTPException(status_code=404, detail="Claim not found")
    # Attach document_url if an FNOL submission with a file exists
    fnol = db.query(FNOLSubmission).filter(FNOLSubmission.claim_id == claim_id).first()
    doc_url = None
    if fnol and fnol.raw_input_path and os.path.exists(fnol.raw_input_path):
        doc_url = f"/api/claims/{claim_id}/document"
    # Build response manually to include extra fields
    out = ClaimOut.model_validate(claim)
    out.incident_description = claim.incident_description
    out.document_url = doc_url
    return out


@router.post("/{claim_id}/decision", response_model=ClaimDecisionOut)
def claim_decision(
    claim_id: int,
    payload: ClaimDecisionPayload,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Adjuster / SIU / Supervisor: approve (settle) or reject a claim."""
    ALLOWED = {"adjuster", "siu_investigator", "supervisor", "admin"}
    if current_user.role not in ALLOWED:
        raise HTTPException(403, "Only adjuster / SIU / supervisor can make decisions")

    claim = db.query(Claim).filter(Claim.id == claim_id).first()
    if not claim:
        raise HTTPException(404, "Claim not found")

    if claim.status not in (
        "escalated_adjuster",
        "escalated_siu",
        "settlement_pending",
    ):
        raise HTTPException(
            400, f"Claim is in '{claim.status}' — decision not applicable"
        )

    if payload.action not in ("approve", "reject", "partial_approve"):
        raise HTTPException(422, "action must be 'approve', 'reject', or 'partial_approve'")

    if payload.action == "partial_approve":
        if payload.amount is None or payload.amount <= 0:
            raise HTTPException(400, "For partial approval, a positive amount must be specified")

    from app.models.models import Settlement, Notification

    now = datetime.utcnow()
    pay_ref = None

    if payload.action in ("approve", "partial_approve"):
        pay_ref = (
            "PAY-"
            + now.strftime("%Y%m%d")
            + "-"
            + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
        )
        exp_by = _next_bday(now, 3)

        settlement = (
            db.query(Settlement).filter(Settlement.claim_id == claim_id).first()
        )
        if not settlement:
            settlement = Settlement(claim_id=claim_id)
            db.add(settlement)

        settlement.payment_reference = pay_ref
        settlement.payment_status = "completed"
        settlement.payment_method = "bank_transfer"
        settlement.approved_by = current_user.id
        settlement.settled_at = now
        
        if payload.action == "partial_approve":
            settlement.net_payout = round(payload.amount, 2)
            settlement.gross_amount = round(payload.amount, 2)
            settlement.deductible_deducted = 0.00
        else:
            if not settlement.net_payout:
                settlement.net_payout = 0

        claim.status = "settled"
        claim.closed_at = now
        new_status = "settled"
        
        if payload.action == "partial_approve":
            msg = (
                f"Claim partially approved by {current_user.full_name} for ₹{settlement.net_payout:,.2f}. "
                f"Payment {pay_ref} initiated — expected by {exp_by.strftime('%d %b %Y')}."
            )
            # Send partial approval email
            notify_claimant_update(
                db,
                claim,
                subject=f"Claim {claim.claim_number} was partially approved",
                body=(
                    f"Hello,\n\n"
                    f"Your claim {claim.claim_number} was partially approved after manual review for an amount of ₹{settlement.net_payout:,.2f}.\n"
                    f"Please find the details in your dashboard.\n"
                ),
                event_type="manual_partial_approve",
                source_status="settled",
                trigger_reason=payload.notes or "Partially approved after manual review.",
            )
        else:
            msg = (
                f"Claim approved by {current_user.full_name}. "
                f"Payment {pay_ref} initiated — expected by {exp_by.strftime('%d %b %Y')}."
            )
    else:
        claim.status = "rejected"
        claim.closed_at = now
        new_status = "rejected"
        reason = payload.notes or "Rejected after manual review."
        msg = f"Claim rejected by {current_user.full_name}. Reason: {reason}"
        notify_claimant_update(
            db,
            claim,
            subject=f"Claim {claim.claim_number} was rejected",
            body=(
                f"Hello,\n\n"
                f"Your claim {claim.claim_number} was rejected after manual review.\n"
                f"Please see the reason below and contact support if you need more information.\n"
            ),
            event_type="manual_reject",
            source_status="rejected",
            trigger_reason=reason,
        )

    # Notify claimant
    if payload.action == "partial_approve":
        title = f"⚠️ Claim {claim.claim_number} Partially Approved"
    elif payload.action == "approve":
        title = f"✅ Claim {claim.claim_number} Approved"
    else:
        title = f"❌ Claim {claim.claim_number} Rejected"

    db.add(
        Notification(
            user_id=claim.claimant_id,
            title=title,
            message=msg,
            claim_id=claim.id,
            is_read=False,
        )
    )
    db.commit()

    return ClaimDecisionOut(
        claim_id=claim.id,
        claim_number=claim.claim_number,
        action=payload.action,
        new_status=new_status,
        payment_ref=pay_ref,
        message=msg,
    )


@router.get("/{claim_id}/document", summary="Download/view the uploaded claim document")
def get_claim_document(
    claim_id: int,
    download: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    claim = db.query(Claim).filter(Claim.id == claim_id).first()
    if not claim:
        raise HTTPException(404, "Claim not found")
    if current_user.role == "policyholder" and claim.claimant_id != current_user.id:
        raise HTTPException(403, "Access denied")
    fnol = db.query(FNOLSubmission).filter(FNOLSubmission.claim_id == claim_id).first()
    if not fnol or not fnol.raw_input_path:
        raise HTTPException(404, "No document attached to this claim")
    fpath = fnol.raw_input_path
    if not os.path.exists(fpath):
        raise HTTPException(404, "Document file not found on server")
    ext = os.path.splitext(fpath)[1].lower()
    media_map = {
        ".pdf": "application/pdf",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".txt": "text/plain",
        ".doc": "application/msword",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    }
    media_type = media_map.get(ext, "application/octet-stream")
    filename = f"claim_{claim.claim_number}{ext}"
    return FileResponse(
        path=fpath,
        media_type=media_type,
        filename=filename,
        content_disposition_type="attachment" if download else "inline",
    )


@router.post("/", response_model=ClaimOut, status_code=201)
def create_claim(
    payload: ClaimCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "policyholder":
        raise HTTPException(
            status_code=403, detail="Only policyholders can file claims"
        )
    claim_number = (
        "CLM-"
        + datetime.utcnow().strftime("%Y")
        + "-"
        + "".join(random.choices(string.digits, k=4))
    )
    claim = Claim(
        claim_number=claim_number,
        policy_id=payload.policy_id,
        claimant_id=current_user.id,
        incident_date=payload.incident_date,
        incident_description=payload.incident_description,
        claim_type=payload.claim_type,
        channel=payload.channel,
        status="fnol_received",
    )
    db.add(claim)
    db.commit()
    db.refresh(claim)
    return claim
