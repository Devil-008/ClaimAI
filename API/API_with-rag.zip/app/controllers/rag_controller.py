"""
RAG Controller — Retrieval Augmented Generation for Claims Assistant
Handles LLM-powered policy Q&A using ChromaDB and Mistral API
"""

import httpx
import logging
from typing import Optional, Dict, Any, List
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.services.vector_store_service import VectorStoreService
from app.core.config import settings
from app.controllers.auth_controller import get_current_user, User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/rag", tags=["RAG"])

# Initialize vector store service
vector_store_service = VectorStoreService()

# ── Request/Response Schemas ────────────────────────────────────


class RAGQueryRequest(BaseModel):
    query: str
    policy_id: Optional[int] = None
    top_k: int = 5


class RAGQueryResponse(BaseModel):
    answer: str
    sources: List[Dict[str, Any]]
    confidence: float
    retrieved_chunks: int


# ── Helper Functions ────────────────────────────────────────────


async def _call_mistral_api(prompt: str) -> Dict[str, Any]:
    """Call the Mistral API with the provided prompt and return the response."""
    if not settings.MISTRAL_API_KEY:
        raise ValueError("Mistral API key is not configured.")

    try:
        async with httpx.AsyncClient(timeout=180.0) as client:
            headers = {
                "Authorization": f"Bearer {settings.MISTRAL_API_KEY.strip()}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            }

            response = await client.post(
                "https://api.mistral.ai/v1/chat/completions",
                headers=headers,
                json={
                    "model": "mistral-small-latest",
                    "messages": [{"role": "system", "content": prompt}],
                },
            )
            response.raise_for_status()
            response_data = response.json()

            # Extract answer from response
            answer = (
                response_data.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "No answer provided.")
            )

            return {
                "answer": answer,
                "confidence": 0.85,  # Default confidence for successful API calls
            }

    except httpx.HTTPStatusError as e:
        logger.error(
            f"Mistral API HTTP error {e.response.status_code}: {e.response.text}"
        )
        return {"answer": "Error calling Mistral API.", "confidence": 0.0}
    except Exception as e:
        logger.error(f"Error calling Mistral API: {e}")
        return {"answer": "Error calling Mistral API.", "confidence": 0.0}


# ── Main RAG Endpoint ───────────────────────────────────────────


@router.post("/chat", response_model=RAGQueryResponse)
async def rag_chat_response(
    req: RAGQueryRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> RAGQueryResponse:
    """
    Retrieval Augmented Generation endpoint for policy Q&A.

    1. Validate input
    2. Generate embedding for user query
    3. Search ChromaDB for relevant chunks
    4. Build context from retrieved chunks
    5. Construct system prompt
    6. Call Mistral API
    7. Return structured response with sources
    """
    try:
        # 1. Validate input
        query = req.query.strip()
        if not query:
            raise ValueError("Query cannot be empty.")

        if len(query) > 5000:
            raise ValueError("Query exceeds maximum length of 5000 characters.")

        sources = []
        relevant_chunks = []

        # 2. Check if Mistral API key is configured
        if not settings.MISTRAL_API_KEY:
            return RAGQueryResponse(
                answer="Mistral API key is not configured in the backend environment. Cannot process RAG query.",
                sources=sources,
                confidence=0.0,
                retrieved_chunks=0,
            )

        # 3. Search ChromaDB for relevant chunks
        try:
            relevant_chunks = vector_store_service.search_similar_chunks(
                query, top_k=req.top_k
            )
        except Exception as e:
            logger.error(f"Error searching vector store: {e}")
            relevant_chunks = []

        # 4. Build context from retrieved chunks
        if relevant_chunks:
            context = "\n\n".join(
                [
                    f"[{chunk['metadata'].get('filename', 'Unknown')}] {chunk['document']}"
                    for chunk in relevant_chunks
                ]
            )
            sources = [
                {
                    "filename": chunk["metadata"].get("filename", "Unknown"),
                    "section": f"Chunk {chunk['metadata'].get('chunk_index', 0)}",
                    "page": None,
                    "distance": chunk.get("distance", None),
                }
                for chunk in relevant_chunks
            ]
        else:
            context = "No relevant information found in the knowledge base."
            sources = []

        # 5. Construct system prompt for Mistral LLM
        system_prompt = f"""You are an expert Insurance Policy Advisor and Claims Assistant.
Use ONLY the retrieved document excerpts to answer the user's question accurately and helpfully.

If the answer is not explicitly present in the retrieved context, clearly state:
"I could not find this specific information in the uploaded policy documents."

Provide:
1. Accurate explanation of the policy term/question.
2. Coverage details and any exclusions if relevant.
3. Benefits and limitations if relevant.
4. Clear source references (document name, section).
5. Your confidence level (High, Medium, Low) based on document clarity.

User Query: {query}

Context from Policy Documents:
{context}

Answer:"""

        # 6. Call Mistral API with constructed prompt
        try:
            response = await _call_mistral_api(system_prompt)
            answer = response.get("answer", "No answer provided.")
            confidence = response.get("confidence", 0.0)
        except Exception as e:
            logger.error(f"Mistral API call failed: {e}")
            answer = (
                "An error occurred while processing your request. Please try again."
            )
            confidence = 0.0

        # 7. Return structured response
        return RAGQueryResponse(
            answer=answer,
            sources=sources,
            confidence=confidence,
            retrieved_chunks=len(relevant_chunks),
        )

    except ValueError as ve:
        logger.error(f"Validation error in rag_chat_response: {ve}")
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        logger.error(f"Error in rag_chat_response: {e}")
        return RAGQueryResponse(
            answer="An unexpected error occurred while processing your request.",
            sources=[],
            confidence=0.0,
            retrieved_chunks=0,
        )


@router.get("/health")
async def rag_health():
    """Health check for RAG service."""
    try:
        # Try to verify vector store is accessible
        vector_store_service.collection
        is_mistral_configured = bool(settings.MISTRAL_API_KEY)

        return {
            "status": "healthy",
            "vector_store": "operational",
            "mistral_configured": is_mistral_configured,
        }
    except Exception as e:
        logger.error(f"RAG health check failed: {e}")
        return {"status": "degraded", "error": str(e)}
